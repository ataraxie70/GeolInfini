# Documents corriges checkMe

Ce dossier contient les documents refondus ou corriges apres l'audit du projet checkMe.

Regle principale :

- ne pas modifier le dossier `files/` ;
- lire `files/` uniquement comme reference historique ;
- produire ici les versions corrigees, une intervention a la fois ;
- commencer par P0-1, puis avancer strictement dans l'ordre defini dans `HISTORIQUE_INTERVENTION.md`.

