# Documents corrigés checkMe!

Ce dossier contient les documents refondus ou corrigés après l'audit du projet checkMe!.

## Règles

- ne pas modifier le dossier `files/` ;
- lire `files/` uniquement comme référence historique ;
- produire ici les versions corrigées, une intervention à la fois ;
- avancer strictement dans l'ordre défini par les interventions ;
- considérer les documents P0-1 à P0-4 comme la baseline canonique courante.

## Baseline actuelle

- `Document_0_Vision_Principes_Fondateurs.md` — vision et principes ;
- `Document_P0_2_Strategie_Recherche_Matching.md` — recherche exacte/floue contrôlée ;
- `Document_P0_3_Fiabilite_Projection_Consultation.md` — outbox, idempotence, projection et générations ;
- `Document_P0_4_Modele_Donnees_Migrations.md` — modèle relationnel et invariants ;
- `migrations/001_extensions_and_schemas.sql` à `005_integrity_indexes.sql` — initialisation PostgreSQL.

## Hypothèse technique P0-4

PostgreSQL est utilisé pour la source de vérité et la projection Consultation du MVP. La projection exacte repose sur un HMAC-SHA-256 calculé côté application après normalisation. Une recherche floue spécialisée reste hors périmètre.

## Prochaine intervention

**P0-5 — conformité, données nominatives, conservation, exposition et audit.**
