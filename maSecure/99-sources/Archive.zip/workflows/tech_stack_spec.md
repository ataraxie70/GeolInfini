# Spécifications de la Stack Technique & Architecture Applicative
**Projet :** MaSecure — Infrastructure de Règlement Social Automatisé
**Dossier :** `workflows/`
**Auteur :** Antigravity AI
**Date :** Juin 2026

---

## 1. Vision d'Architecture Globale
MaSecure est conçu comme un système distribué hautement sécurisé, résilient et modulaire. L'architecture sépare les préoccupations financières critiques (Kernel), l'orchestration des flux sociaux (APIs, Gouvernance) et les terminaux clients (Web Admin, Mobile App, Passerelles WhatsApp/SMS).

```text
                  ┌──────────────────────────────────────────────┐
                  │                 CLIENT LAYER                 │
                  │  - Mobile Client (Flutter / USSD)            │
                  │  - Web Admin Dashboard (React / Vite)         │
                  │  - Gateway Comm. (WhatsApp / SMS Webhooks)   │
                  └──────────────────────┬───────────────────────┘
                                         │ (HTTPS + HMAC / REST)
                                         ▼
                  ┌──────────────────────────────────────────────┐
                  │              ORCHESTRATION LAYER             │
                  │  - API Gateway (Go - Envoy/Custom Router)    │
                  │  - Social & Governance Service (Go)          │
                  └──────────────────────┬───────────────────────┘
                                         │ (gRPC / mTLS)
                                         ▼
                  ┌──────────────────────────────────────────────┐
                  │                FINANCIAL CORE                │
                  │  - Kernel Financier Déterministe (Rust)      │
                  │  - Outbox Worker & Retrier (Go)              │
                  └──────────────────────┬───────────────────────┘
                                         │ (ACID Transactions)
                                         ▼
                  ┌──────────────────────────────────────────────┐
                  │              PERSISTENCE LAYER               │
                  │  - PostgreSQL 16 (Ledger, Transactions, State)│
                  │  - Redis (Idempotency, Session, Locks)       │
                  │  - NATS JetStream (Async Event Stream)       │
                  └──────────────────────────────────────────────┘
```

---

## 2. Choix Technologiques Détaillés

### 2.1. Le Backend (Orchestration & Finance)

* **Noyau Financier (Kernel) : Rust**
  * *Rôle :* Automate d'états, chaîne de hachage du ledger, signature des transferts de fonds.
  * *Justification :* Sûreté mémoire garantie sans garbage collector, typage fort, exécution ultra-rapide et déterministe. Élimine les failles de corruption de mémoire ou de dépassement d'entier (integer overflow) fréquentes dans les transactions financières.
* **Services Applicatifs & API Gateway : Go (Golang)**
  * *Rôle :* Service Social (membres, groupes), Service de Gouvernance (votes, propositions), API Gateway et Outbox Worker.
  * *Justification :* Concurrence native légère (goroutines), rapidité de développement d'APIs REST, binaire unique compilé et performance réseau élevée.
* **Base de Données Principale : PostgreSQL 16**
  * *Rôle :* Persistance des données relationnelles opérationnelles et stockage physique du ledger chaîné.
  * *Justification :* Support ACID complet, contraintes d'intégrité référentielle fortes, extensibilité via déclencheurs (triggers PL/pgSQL) et indexation JSONB robuste.
* **Base de Caching et Verrous : Redis**
  * *Rôle :* Verrous distribués (pour empêcher les requêtes simultanées de double paiement) et stockage temporaire des sessions.
* **Bus d'Événements : NATS JetStream**
  * *Rôle :* Propagation asynchrone des événements de domaine (`MemberSuspended`, `ContributionReceived`) vers le Gateway de notification.

---

### 2.2. L'Application Mobile (Client Final)

Nous recommandons d'adopter **Flutter (Dart)** pour le développement mobile client, avec **React Native (TypeScript)** comme alternative secondaire.

* **Option Recommandée : Flutter (Dart)**
  * *Rôle :* Application mobile pour les membres et les responsables de groupe.
  * *Justification :*
    1. **Performance sur téléphones bas de gamme (Low-end Android) :** Très répandus en Afrique de l'Ouest. Contrairement à React Native, Flutter n'utilise pas de pont (bridge) JavaScript ; il compile directement en code machine natif (AOT) et dessine ses propres widgets via le moteur Skia/Impeller. Cela garantit une interface fluide à 60 FPS, même sur des smartphones d'entrée de gamme.
    2. **Gestion du mode hors-ligne (Offline-First) :** La connectivité réseau étant intermittente (2G/3G instable), l'application locale doit pouvoir stocker les données du ledger et l'état du groupe. Les bases de données embarquées rapides de Flutter (comme Hive ou Isar) facilitent ce stockage local avec chiffrement AES-256 transparent.
    3. **Interface multi-plateforme unique :** Un seul code-source pour Android et iOS.
* **Alternative : React Native (TypeScript)**
  * *Justification :* Permet de partager le code de validation (TypeScript) et les définitions de types d'API avec le Dashboard Web (React). Cependant, il est plus consommateur de ressources sur les terminaux limités.

---

### 2.3. Le Dashboard Web d'Administration

Le back-office pour les super-administrateurs de MaSecure, les administrateurs opérationnels et les responsables de groupe souhaitant un grand écran.

* **Stack Choisie : React.js + Vite (TypeScript)**
  * *Rôle :* Interface d'administration web.
  * *Justification :*
    1. **Rapidité d'exécution :** Vite remplace Webpack pour offrir un rechargement à chaud (HMR) instantané et des builds de production extrêmement optimisés et légers.
    2. **Richesse de l'écosystème :** Accès à des bibliothèques de graphiques interactifs (Recharts/Chart.js) pour visualiser en temps réel la santé financière des tontines, le taux de réconciliation et l'activité du hub bancaire.
    3. **Sécurité :** TypeScript sécurise la manipulation des modèles de données complexes du dictionnaire relationnel.
* **Design System :** Styling via Vanilla CSS avec variables personnalisées (Custom Properties) pour un contrôle total de la charte graphique premium.

---

## 3. Topologie des Réseaux et Intégrations API

1. **Intégration Mobile Money (Orange, Moov, Wave) :**
   * Canaux sécurisés de callbacks via signature HMAC-SHA256 obligatoire.
   * L'outbox worker Go s'interface avec les agrégateurs de paiement locaux via des requêtes REST authentifiées et sécurisées.
2. **Passerelles SMS / WhatsApp Business API :**
   * Utilisation de l'API Cloud de Meta pour WhatsApp avec vérification des webhooks entrants (signature `X-Hub-Signature-256`).
   * Service de SMS de secours (fallback) branché sur des opérateurs régionaux (ex : SMS-To-Africa, Twilio ou opérateurs locaux).
