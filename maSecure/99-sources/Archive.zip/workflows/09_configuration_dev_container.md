# Spécification et Architecture du Conteneur de Développement (Dev Container)
**Projet :** MaSecure — Infrastructure de Règlement Social Automatisé
**Dossier :** `workflows/`
**Auteur :** Antigravity AI
**Date :** Juin 2026

---

## 1. Vision et Objectifs du Dev Container
Pour assurer une collaboration fluide et éliminer le syndrome du « ça marche sur ma machine », nous mettons en place un **Dev Container** standardisé (norme VS Code / Dev Containers). 

### Principes retenus :
1. **Base Ubuntu Propre :** Nous refusons les images génériques pré-construites (souvent trop lourdes ou polluées par des conflits de versions). Nous partons d'une image de base officielle `ubuntu:22.04 LTS` légère et installons uniquement les dépendances requises pour notre projet.
2. **Isolation Complète des Outils :** Tous les runtimes nécessaires (Rust, Go, Flutter, Node.js) sont installés à l'intérieur du conteneur. Aucun outil n'est requis sur le système hôte (hormis Docker et VS Code).
3. **Gestion Node via Volta :** Volta est installé comme gestionnaire d'outils JavaScript. Il permet d'épingler la version de Node.js et de npm directement dans le `package.json` du dashboard web, garantissant que tous les développeurs exécutent la même version de Node sans manipulation manuelle de `nvm`.
4. **Intégration Flutter :** Le conteneur embarque le SDK Flutter, le SDK Dart et le JDK Java (requis par la suite d'outils Android) ainsi que les dépendances système Linux nécessaires pour compiler ou exécuter des outils d'analyse de code.

---

## 2. Runtimes & Outils Embarqués

Le conteneur compile et configure les runtimes suivants :

| Outil | Méthode d'Installation | Rôle |
| :--- | :--- | :--- |
| **Go** | Téléchargement du binaire officiel (tarball) | API Gateway, Services Sociaux et Outbox. |
| **Rust** | Script officiel `rustup` | Kernel Financier. |
| **Java JDK 17** | `openjdk-17-jdk` via APT | Compilateur Java requis pour l'environnement Android/Flutter. |
| **Flutter SDK** | Archive tar officielle | SDK de développement d'applications mobiles. |
| **Volta** | Script d'installation officiel | Gestionnaire Node.js et npm. |

---

## 3. Configuration des Dossiers du Projet

Les fichiers de configuration du Dev Container sont stockés dans le sous-dossier `.devcontainer/` à la racine du projet réel, soit `platform/.devcontainer/` :

1. **`platform/.devcontainer/devcontainer.json`** : Paramètre le comportement du conteneur, monte le workspace, expose les ports (3000 pour React, 8080 pour l'API Go) et pré-installe les extensions recommandées pour VS Code (Rust-analyzer, Go, Flutter, Dart, ESLint).
2. **`platform/.devcontainer/Dockerfile`** : Script d'automatisation de l'image de développement basée sur Ubuntu 22.04, créant un utilisateur non-privilégié `vscode` avec accès sudo.
