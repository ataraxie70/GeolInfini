# Stratégie de Compilation iOS & Intégration dans le Dev Container
**Projet :** MaSecure — Infrastructure de Règlement Social Automatisé
**Dossier :** `workflows/`
**Auteur :** Antigravity AI
**Date :** Juin 2026

---

## 1. Problématique de la Compilation iOS en Conteneur
Pour compiler, signer et empaqueter une application pour iPhone/iOS (format `.ipa`), Apple impose l'utilisation de **Xcode**, qui ne s'exécute nativement que sous **macOS**. 
* **La Contrainte :** Docker tournant sous Linux ou Windows ne peut pas émuler macOS pour compiler l'application iOS. Le Dev Container (basé sur Ubuntu) permet d'écrire le code Dart de Flutter et de lancer l'application sous Android/Web, mais pas de générer un build iOS en local sur une machine non-Mac.

---

## 2. Architecture de Compilation Multi-Plateforme (iOS / Android)

Pour contourner cette limite matérielle tout en conservant une structure unique et portable, nous recommandons une architecture hybride combinant le Dev Container pour le code, et le Cloud/CI-CD pour la compilation iOS.

```text
       [ Développeur (Dev Container - Linux/Windows/macOS) ]
                               │
                       (Écrit Code Dart Unique)
                               │
            ┌──────────────────┴──────────────────┐
            ▼ (Push Git)                          ▼ (Local macOS Host)
   [ CI-CD Cloud (macOS Runner) ]        [ Xcode Local (macOS) ]
    - GitHub Actions / Codemagic          - Build & Run Simulator iOS
    - Fastlane Integration                - Local Signature (Ad-hoc)
            │                                     │
            ▼                                     ▼
     [ IPA Compilé ]                       [ App sur iPhone Test ]
  (App Store / TestFlight)
```

### 2.1. Étape 1 : Développement unifié dans le Dev Container
Le développeur travaille sur l'application mobile Flutter dans le Dev Container.
* Il écrit du code Dart 100% compatible Android & iOS.
* Les tests unitaires et de widgets mobiles s'exécutent directement dans le conteneur (`flutter test`).
* L'analyse de code (linting) et le formatage sont validés uniformément.

### 2.2. Étape 2 : Compilation iOS en Cloud (CI-CD) - *Recommandé*
Pour les équipes travaillant sur Linux/Windows, la compilation iOS est automatisée sur un pipeline de CI-CD disposant d'environnements macOS.
1. **GitHub Actions (ou GitLab CI) :** Utilisation de serveurs virtuels macOS (`runs-on: macos-latest`). Le pipeline récupère le code, installe Flutter, configure les certificats de provisionnement d'Apple et compile l'application via la commande :
   ```bash
   flutter build ipa --export-method=ad-hoc
   ```
2. **Codemagic (Spécialisé Flutter) :** Plateforme cloud qui gère automatiquement la signature des profils de provisionnement Apple et génère le fichier `.ipa` à chaque commit sur la branche principale.

### 2.3. Étape 3 : Exécution en local pour développeurs sous macOS
Si un collaborateur travaille sur un ordinateur Mac (Intel ou Apple Silicon M1/M2/M3) :
* Il peut lancer VS Code et ouvrir le dossier du projet via le Dev Container (Docker sous macOS).
* **Déviation locale (Bridge) :** Pour tester sur un simulateur iOS local, il ferme le Dev Container et ouvre le dossier directement dans son macOS hôte. Comme le code Dart est le même et que les versions d'outils Node/Flutter sont calées, le build Xcode s'exécute sans problème sur son Mac.

---

## 3. Configuration Minimale Requise pour le Compte Apple Developer
Pour publier et tester sur iPhone, l'organisation devra :
1. Adhérer au **Apple Developer Program** (99 USD / an).
2. Générer un **Certificat de Distribution iOS** et un **Profil de Provisionnement** (Provisioning Profile) lié aux identifiants (UUID) des téléphones de test des responsables ou des clients pilotes.
3. Configurer **Fastlane** dans le sous-dossier `platform/frontend/mobile_app/ios/` pour automatiser la signature cryptographique et l'envoi vers **TestFlight** (plateforme de test bêta d'Apple).
