# Spécifications des Migrations de Base de Données (PostgreSQL)
**Projet :** MaSecure — Infrastructure de Règlement Social Automatisé
**Dossier :** `workflows/`
**Auteur :** Antigravity AI
**Date :** Juin 2026

---

## 1. Plan Général des Migrations
La suite logique immédiate de l'implémentation est de mettre à jour le schéma PostgreSQL. Nous concevons deux fichiers de migration distincts qui seront stockés dans le dossier `platform/migrations/` :

1. **`008_governance.sql` :** Initialisation du module de gouvernance partagée (propositions de modifications et votes).
2. **`009_schema_extensions.sql` :** Implémentation des mécanismes validés (successeur légal, fractionnement progressif du fonds de recouvrement, taxes Mobile Money et triggers de sécurité).

---

## 2. Structure Détaillée de la Migration 008 : Gouvernance

Cette migration introduit les tables de propositions et de votes indispensables à la Phase 3 (Gouvernance versionnée).

### Invariants et Contraintes :
* Une proposition (`proposals`) doit obligatoirement faire référence à un groupe et à une configuration de base.
* Le statut d'une proposition suit l'énumération : `open` (ouverte), `approved` (approuvée), `rejected` (rejetée).
* L'unicité `UNIQUE(proposal_id, identity_id)` sur les votes garantit qu'un membre ne peut voter qu'une seule fois par consultation.

---

## 3. Structure Détaillée de la Migration 009 : Garde-fous Financiers

Cette migration met à jour le modèle relationnel pour y inclure les correctifs métier :

### Invariants et Contraintes :
* **Lien Successor :** Ajout de la colonne `successor_identity_id` sur la table `members` avec clé étrangère vers `identities` pour permettre la substitution en cas de décès.
* **Financement Progressif :** Intégration de `fonds_mode_financement` (integral/progressif) et suivi des montants cible vs accumulé dans `group_configs`.
* **Répartition des Frais :** Stockage des frais opérateurs et target d'imputation (`frais_billing_target` = `fonds_recouvrement` ou `pot_beneficiaire`) sur `ledger_entries` pour automatiser la déduction.
* **Trigger de Sécurité :** Déploiement du trigger `enforce_fonds_completion_before_payout` qui vérifie que le fonds de recouvrement progressif est complet avant d'autoriser le versement du premier cycle.
